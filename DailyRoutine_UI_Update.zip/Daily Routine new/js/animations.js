/* Shared motion system: soft reveals, hover micro-interactions, progress animation. */
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add("revealed"); observer.unobserve(entry.target); }
    }), { threshold: 0.08 });
    items.forEach(item => observer.observe(item));
  } else items.forEach(item => item.classList.add("revealed"));
  document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("pointermove", e => {
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty("--pointer-x", `${e.clientX-r.left}px`);
      card.style.setProperty("--pointer-y", `${e.clientY-r.top}px`);
    });
  });
});
