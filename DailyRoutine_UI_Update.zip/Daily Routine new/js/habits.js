document.addEventListener("DOMContentLoaded",()=>{
 const key="dailyRoutineHabits-"+new Date().toISOString().slice(0,10);
 let saved={};try{saved=JSON.parse(localStorage.getItem(key)||"{}")}catch{}
 const checks=[...document.querySelectorAll("[data-habit]")];
 checks.forEach(input=>{input.checked=Boolean(saved[input.dataset.habit]);input.closest(".habit-tile")?.classList.toggle("is-done",input.checked);input.addEventListener("change",()=>{saved[input.dataset.habit]=input.checked;localStorage.setItem(key,JSON.stringify(saved));input.closest(".habit-tile")?.classList.toggle("is-done",input.checked);window.showToast?.(input.checked?"Habit checked off — nice work!":"Habit unchecked.");});});
 const update=()=>{const total=document.getElementById("routineTotal"),done=document.getElementById("routineCompleted"),remaining=document.getElementById("routineRemaining");const tasks=JSON.parse(localStorage.getItem("routineTasks")||"[]");if(total)total.textContent=tasks.length;if(done)done.textContent=tasks.filter(t=>t.completed).length;if(remaining)remaining.textContent=tasks.filter(t=>!t.completed).length;};
 update();document.getElementById("taskList")?.addEventListener("change",()=>setTimeout(update,0));document.getElementById("taskList")?.addEventListener("click",()=>setTimeout(update,0));
});
