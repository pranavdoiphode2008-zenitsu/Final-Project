DAILYROUTINE UI UPDATE

This update refreshes the logged-in pages to use a consistent dark productivity workspace inspired by the visual reference: emerald accent, sidebar navigation, responsive cards, routines, habit check-ins, analytics charts, AI plan builder, settings, and subtle motion.

HOW TO APPLY
1. Unzip this package.
2. Copy the included css/, frontend/, and js/ files into your existing Daily Routine new project, preserving the same folders and choosing Replace when asked.
3. Do NOT replace or delete backend/.env. It contains your local configuration and is intentionally not included.
4. Run the frontend server from the project root: npx http-server . -p 5501
5. Open http://localhost:5501/frontend/dashboard.html (after logging in) or http://localhost:5501/frontend/index.html.
6. Keep your backend running in a second terminal: cd backend ; npm run dev

NOTES
- The routine list, habit check-ins, theme, accent and generated plans in this UI are saved in browser localStorage in this version. They are not yet synced to MongoDB.
- The planner creates a structured template locally; it does not call a paid or remote AI service.
- For security, this update does not include .env or node_modules.
